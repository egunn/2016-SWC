
function foo() {
    alert("hey");
}

function thing(x) {
    while (x < 10) {
        console.log("hey " + x);
        x++;
    }
}

thing(4);