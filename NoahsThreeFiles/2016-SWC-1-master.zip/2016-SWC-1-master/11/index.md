# Class 11 – 2016-11-22: D3 Part Two

## New problem set [ps-11](ps-11.html)


## Review problem set 10:  5:45 – 7:00
* Review [ps-010](../10/ps-10.html)

### D3: Review of Axis & Scales: 7:00 - 7:20

### D3 MAPS: 7:20 - 7:40

Together we are going to make a map my world travels.
- Generate a bas map using: [Map Starter](http://mapstarter.com/)
- Options: Convert to and from map formats: [MapShaper](http://mapshaper.org/)
- Add data points using: [GeoJasonIO](http://geojson.io/)

### Multiple Concurrent Views: 8:00 - 8:45
- VOTE:  Should we do a Clock example, or a map example?
- Work on it together.
